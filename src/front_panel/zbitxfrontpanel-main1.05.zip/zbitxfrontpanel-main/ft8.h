//void ft8_select()
void ft8_update(const char *msg);
void ft8_draw(field *f);
void ft8_input(int input);
void ft8_init();