void console_init();
void console_update(struct field *f, const char *label, const char *text);
void console_draw(field *f);
