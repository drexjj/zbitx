void logbook_init();
void logbook_draw(struct field *f);
void logbook_update(const char *update_str);
void logbook_input(int input);
